const DB_NAME = "my-state-local";
const DB_VERSION = 1;
const STORES = ["meds","mood","sleep","diary","traits"];
let db;
let diaryRange = null;

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const d=req.result;
      for(const s of STORES) if(!d.objectStoreNames.contains(s)) d.createObjectStore(s,{keyPath:"id",autoIncrement:true});
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
function all(store){
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readonly"),req=tx.objectStore(store).getAll();
    req.onsuccess=()=>resolve(req.result.sort((a,b)=>(b.created||"").localeCompare(a.created||"")));
    req.onerror=()=>reject(req.error);
  });
}
function add(store,value){
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readwrite");
    const req=tx.objectStore(store).add({...value,created:new Date().toISOString()});
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
}
function remove(store,id){
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readwrite");tx.objectStore(store).delete(Number(id));
    tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
  });
}
function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function fmt(v){return v?new Date(v).toLocaleString("ru-RU"):"";}
function localDateTime(){
  const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);
}
function localDate(){return localDateTime().slice(0,10);}
function show(view){
  document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id===`view-${view}`));
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  if(view==="home") renderRecent();
  if(view==="meds") renderMeds();
  if(view==="mood") renderMood();
  if(view==="sleep") renderSleep();
  if(view==="diary") renderDiary();
  if(view==="personality") renderTraits();
}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.view)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.go)));

function card(title,sub,body,store,id){
  return `<article class="entry"><div class="entry-title">${esc(title)}</div><small>${esc(sub||"")}</small>${body||""}<div class="entry-actions"><button class="delete" data-delete="${store}:${id}">Удалить</button></div></article>`;
}
document.addEventListener("click",async e=>{
  const b=e.target.closest("[data-delete]");if(!b)return;
  const [store,id]=b.dataset.delete.split(":");
  if(confirm("Удалить эту запись?")){await remove(store,id);refreshAll();}
});
async function renderMeds(){
  const items=await all("meds");
  document.querySelector("#med-list").innerHTML=items.length?items.map(x=>card(x.name,`${x.time} · ${x.frequency}${x.days?" · "+x.days:""}`,"","meds",x.id)).join(""):"<p class='muted'>Препаратов пока нет.</p>";
}
async function renderMood(){
  const items=await all("mood");
  document.querySelector("#mood-list").innerHTML=items.map(x=>card(`${x.score}/5`,fmt(x.date),x.note?`<p>${esc(x.note)}</p>`:"","mood",x.id)).join("")||"<p class='muted'>Оценок пока нет.</p>";
}
async function renderSleep(){
  const items=await all("sleep");
  document.querySelector("#sleep-list").innerHTML=items.map(x=>card(`Качество: ${x.quality}/5`,`${x.date} · ${x.bed}–${x.wake}`,`<p>${x.woke==="yes"?"Пробуждения: "+esc((x.wakeTimes||[]).join(", ")):"Ночных пробуждений не было"}</p>${x.note?`<p>${esc(x.note)}</p>`:""}`,"sleep",x.id)).join("")||"<p class='muted'>Записей о сне пока нет.</p>";
}
async function renderDiary(){
  let items=await all("diary");
  if(diaryRange) items=items.filter(x=>x.date.slice(0,10)>=diaryRange.from&&x.date.slice(0,10)<=diaryRange.to);
  document.querySelector("#diary-list").innerHTML=items.map(x=>card("Запись",fmt(x.date),`${x.body?`<p>${esc(x.body)}</p>`:""}${x.dream?`<p><b>Сон</b><br>${esc(x.dream)}</p>`:""}`,"diary",x.id)).join("")||"<p class='muted'>Записей за этот период нет.</p>";
}
async function renderTraits(){
  const items=await all("traits");
  document.querySelector("#trait-list").innerHTML=items.map(x=>card(x.topic,"Наблюдения по фазам",`<p><b>Депрессия:</b> ${esc(x.depression)}</p><p><b>Стабильность:</b> ${esc(x.stable)}</p><p><b>Гипомания:</b> ${esc(x.hypomania)}</p>`,"traits",x.id)).join("")||"<p class='muted'>Добавь первую сферу наблюдения.</p>";
}
async function renderRecent(){
  const [m,d,s]=await Promise.all([all("mood"),all("diary"),all("sleep")]);
  const rows=[...m.slice(0,2).map(x=>`Настроение ${x.score}/5 · ${fmt(x.date)}`),...s.slice(0,2).map(x=>`Сон ${x.quality}/5 · ${x.date}`),...d.slice(0,2).map(x=>`Дневник · ${fmt(x.date)}`)].slice(0,5);
  document.querySelector("#recent").innerHTML=rows.length?rows.map(x=>`<p>${esc(x)}</p>`).join(""):"Пока записей нет.";
}
function formObject(form){
  return Object.fromEntries(new FormData(form).entries());
}
document.querySelector("#med-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.currentTarget,v=formObject(f);await add("meds",v);f.reset();await renderMeds();
});
document.querySelector("#mood-range").addEventListener("input",e=>document.querySelector("#mood-value").textContent=e.target.value);
document.querySelector("#mood-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.currentTarget,v=formObject(f);v.score=Number(v.score);await add("mood",v);f.reset();f.elements.date.value=localDateTime();document.querySelector("#mood-value").textContent="3";await renderMood();
});
document.querySelector("#sleep-range").addEventListener("input",e=>document.querySelector("#sleep-value").textContent=e.target.value);
document.querySelectorAll('input[name="woke"]').forEach(x=>x.addEventListener("change",()=>{
  document.querySelector("#wake-times-wrap").hidden=document.querySelector('input[name="woke"]:checked').value!=="yes";
}));
function addWakeRow(value=""){
  const row=document.createElement("div");row.className="wake-row";
  row.innerHTML=`<input type="time" aria-label="Время ночного пробуждения" value="${esc(value)}"><button type="button" aria-label="Удалить время">×</button>`;
  row.querySelector("button").addEventListener("click",()=>row.remove());
  document.querySelector("#wake-times").append(row);
}
document.querySelector("#add-wake").addEventListener("click",()=>addWakeRow());
document.querySelector("#sleep-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.currentTarget,v=formObject(f);
  v.quality=Number(v.quality);v.wakeTimes=[...document.querySelectorAll("#wake-times input")].map(x=>x.value).filter(Boolean);
  if(v.woke==="yes"&&!v.wakeTimes.length){alert("Добавь время ночного пробуждения.");return;}
  await add("sleep",v);f.reset();f.elements.date.value=localDate();document.querySelector("#wake-times").innerHTML="";
  document.querySelector("#wake-times-wrap").hidden=true;document.querySelector("#sleep-value").textContent="3";addWakeRow();await renderSleep();
});
document.querySelector("#diary-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.currentTarget,v=formObject(f);
  if(!v.body.trim()&&!v.dream.trim()){alert("Добавь текст записи или описание сна.");return;}
  await add("diary",v);f.reset();f.elements.date.value=localDateTime();diaryRange=null;await renderDiary();
});
document.querySelector("#diary-filter").addEventListener("click",async()=>{
  const from=document.querySelector("#diary-from").value,to=document.querySelector("#diary-to").value;
  if(!from||!to||from>to){alert("Укажи корректный диапазон дат.");return;}
  diaryRange={from,to};await renderDiary();
});
document.querySelector("#diary-clear").addEventListener("click",async()=>{diaryRange=null;document.querySelector("#diary-from").value="";document.querySelector("#diary-to").value="";await renderDiary();});
document.querySelector("#trait-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.currentTarget;await add("traits",formObject(f));f.reset();await renderTraits();
});

function csvCell(v){let s=String(v??"");return `"${s.replace(/"/g,'""')}"`;}
function download(name,content,type="text/csv;charset=utf-8"){
  const blob=new Blob(["\ufeff",content],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const exports={
 meds:{headers:["Название","Время","Периодичность","Дни"],map:x=>[x.name,x.time,x.frequency,x.days]},
 mood:{headers:["Дата и время","Оценка","Комментарий"],map:x=>[x.date,x.score,x.note]},
 sleep:{headers:["Дата пробуждения","Время отхода ко сну","Время пробуждения","Качество 0-5","Было ночное пробуждение","Время ночных пробуждений","Комментарий"],map:x=>[x.date,x.bed,x.wake,x.quality,x.woke,(x.wakeTimes||[]).join("; "),x.note]},
 diary:{headers:["Дата и время","Основная запись","Приснившийся сон"],map:x=>[x.date,x.body,x.dream]},
 traits:{headers:["Сфера","Депрессивная фаза","Стабильное состояние","Гипоманиакальная фаза"],map:x=>[x.topic,x.depression,x.stable,x.hypomania]}
};
document.querySelectorAll("[data-export]").forEach(b=>b.addEventListener("click",async()=>{
  const key=b.dataset.export,items=await all(key),spec=exports[key];
  const csv=[spec.headers,...items.map(spec.map)].map(row=>row.map(csvCell).join(";")).join("\r\n");
  download(`${key}.csv`,csv);document.querySelector("#export-status").textContent="Файл сформирован.";
}));
document.querySelector("#backup").addEventListener("click",async()=>{
  const data={exportedAt:new Date().toISOString()};
  for(const s of STORES)data[s]=await all(s);
  download("my-state-backup.json",JSON.stringify(data,null,2),"application/json");
  document.querySelector("#export-status").textContent="Резервная копия сформирована.";
});
async function refreshAll(){await Promise.all([renderMeds(),renderMood(),renderSleep(),renderDiary(),renderTraits(),renderRecent()]);}
(async()=>{
  db=await openDB();
  document.querySelector('#mood-form [name="date"]').value=localDateTime();
  document.querySelector('#diary-form [name="date"]').value=localDateTime();
  document.querySelector('#sleep-form [name="date"]').value=localDate();
  addWakeRow();
  await refreshAll();
  document.querySelector("#connection").textContent=navigator.onLine?"Готово":"Офлайн";
  window.addEventListener("online",()=>document.querySelector("#connection").textContent="Готово");
  window.addEventListener("offline",()=>document.querySelector("#connection").textContent="Офлайн");
})().catch(err=>{console.error(err);alert("Не удалось открыть локальную базу данных.");});
